import java.util.Scanner;

public class Tabung extends BangunRuang {
    private double tinggi;
    private double jariJari;

    public Tabung(String name) {
        super(name);
    }

    @Override
    public void inputNilai() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Input tinggi: ");
        tinggi = scanner.nextDouble();
        System.out.print("Input jari-jari: ");
        jariJari = scanner.nextDouble();
    }

    @Override
    public void luasPermukaan() {
        double hasil = 2 * Math.PI * jariJari * (jariJari + tinggi);
        System.out.println("Hasil luas permukaan Tabung: " + hasil);
    }

    @Override
    public void volume() {
        double hasil = Math.PI * jariJari * jariJari * tinggi;
        System.out.println("Hasil volume Tabung: " + hasil);
    }
}
